from pymongo import MongoClient
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg

# MongoDB 데이터 가져오기
client = MongoClient("mongodb://127.0.0.1:27017/")
data = list(client["sns_psychology"]["responses"].find(
    {}, {"_id": 0, "user_id": 1, "sns_hours": 1, "stress_score": 1}
))
client.close()

# Spark 실행
spark = SparkSession.builder \
    .master("local[2]") \
    .appName("SNS_Analysis") \
    .getOrCreate()

try:
    if not data:
        print("분석할 데이터가 없습니다.")
    else:
        df = spark.createDataFrame(data)

        print("=== SNS 데이터 ===")
        df.show()

        print("=== 평균 분석 ===")
        df.select(
            avg("sns_hours").alias("avg_sns_hours"),
            avg("stress_score").alias("avg_stress_score")
        ).show()
finally:
    spark.stop()
